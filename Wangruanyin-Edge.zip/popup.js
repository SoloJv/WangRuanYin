// Files to inject when the content script isn't loaded yet (must match manifest)
const INJECT_FILES = [
  "pinyin-dict-characters.js",
  "pinyin-data.js",
  "hsk2-char-levels.js",
  "hsk3-char-levels.js",
  "content.js"
];

// Load toggle states from storage
chrome.storage.local.get(['pinyinEnabled', 'selectionEnabled', 'targetLang', 'hskMode', 'hskDisabledLevels'], (result) => {
  const pinyinToggle = document.getElementById('togglePinyin');
  const selectionToggle = document.getElementById('toggleSelection');
  const langSelect = document.getElementById('targetLang');

  pinyinToggle.checked = result.pinyinEnabled !== false; // default ON
  selectionToggle.checked = result.selectionEnabled === true; // default OFF
  langSelect.value = result.targetLang || 'en'; // default English

  // HSK mode (off / hsk2 / hsk3)
  const hskMode = result.hskMode || 'off';
  const hskDisabledLevels = Array.isArray(result.hskDisabledLevels) ? result.hskDisabledLevels : [];
  const hskOff = document.querySelector('input[name="hskMode"][value="off"]');
  const hsk2 = document.querySelector('input[name="hskMode"][value="hsk2"]');
  const hsk3 = document.querySelector('input[name="hskMode"][value="hsk3"]');
  if (hsk2) hsk2.checked = (hskMode === 'hsk2');
  if (hsk3) hsk3.checked = (hskMode === 'hsk3');
  if (hskOff) hskOff.checked = (hskMode === 'off');

  // Pinyin annotation toggle
  pinyinToggle.addEventListener('change', () => {
    const newState = pinyinToggle.checked;
    chrome.storage.local.set({ pinyinEnabled: newState }, () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (!tabs[0]) return;
        if (newState) {
          chrome.tabs.sendMessage(tabs[0].id, { action: "enable_pinyin" }, (response) => {
            if (chrome.runtime.lastError) {
              chrome.scripting.executeScript(
                {
                  target: { tabId: tabs[0].id },
                  files: INJECT_FILES
                },
                () => {
                  if (!chrome.runtime.lastError) {
                    setTimeout(() => {
                      chrome.tabs.sendMessage(tabs[0].id, { action: "enable_pinyin" });
                    }, 200);
                  }
                }
              );
            }
          });
        } else {
          chrome.tabs.sendMessage(tabs[0].id, { action: "disable_pinyin" });
        }
      });
    });
  });

  // Selection translation toggle
  selectionToggle.addEventListener('change', () => {
    const newState = selectionToggle.checked;
    chrome.storage.local.set({ selectionEnabled: newState }, () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (!tabs[0]) return;
        const action = newState ? "enable_selection_mode" : "disable_selection_mode";
        chrome.tabs.sendMessage(tabs[0].id, { action }, (response) => {
          if (chrome.runtime.lastError && newState) {
            // Content script not loaded yet: inject scripts and retry
            chrome.scripting.executeScript(
              {
                target: { tabId: tabs[0].id },
                files: INJECT_FILES
              },
              () => {
                if (!chrome.runtime.lastError) {
                  setTimeout(() => {
                    chrome.tabs.sendMessage(tabs[0].id, { action });
                  }, 200);
                }
              }
            );
          }
        });
      });
    });
  });

  // Target language selector
  langSelect.addEventListener('change', () => {
    const newLang = langSelect.value || 'en';
    chrome.storage.local.set({ targetLang: newLang }, () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (!tabs[0]) return;
        chrome.tabs.sendMessage(
          tabs[0].id,
          { action: "set_target_lang", lang: newLang },
          (response) => {
            if (chrome.runtime.lastError) {
              // content script not loaded - nothing to re-translate now
            }
          }
        );
      });
    });
  });

  // HSK colour coding mode
  const hskRadios = document.querySelectorAll('input[name="hskMode"]');
  function updateHskLegend(mode, disabledLevels) {
    const maxLevel = mode === 'hsk3' ? 7 : (mode === 'hsk2' ? 6 : 0);
    document.querySelectorAll('#hskLegend .hsk-color').forEach(sw => {
      const lv = parseInt(sw.getAttribute('data-level'), 10);
      const visible = (lv >= 1 && lv <= maxLevel);
      // Use BOTH 'hidden' and explicit display so a swatch can never
      // accidentally collapse for the mode it belongs to.
      sw.hidden = !visible;
      sw.style.display = visible ? '' : 'none';
      if (visible) {
        sw.textContent = (mode === 'hsk3' && lv === 7) ? '7-9' : String(lv);
        sw.classList.toggle('off', disabledLevels.indexOf(lv) !== -1);
        sw.setAttribute('aria-pressed', disabledLevels.indexOf(lv) !== -1 ? 'false' : 'true');
      }
    });
  }
  updateHskLegend(hskMode, hskDisabledLevels);

  // Click a colour to turn that HSK level's colouring on/off
  document.querySelectorAll('#hskLegend .hsk-color').forEach(sw => {
    sw.addEventListener('click', () => {
      const lv = parseInt(sw.getAttribute('data-level'), 10);
      if (!lv || hskMode === 'off') return;
      const idx = hskDisabledLevels.indexOf(lv);
      if (idx === -1) hskDisabledLevels.push(lv); else hskDisabledLevels.splice(idx, 1);
      hskDisabledLevels.sort((a, b) => a - b);
      updateHskLegend(hskMode, hskDisabledLevels);
      chrome.storage.local.set({ hskDisabledLevels }, () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (!tabs[0]) return;
          chrome.tabs.sendMessage(
            tabs[0].id,
            { action: "set_hsk_levels", levels: hskDisabledLevels },
            () => {
              if (chrome.runtime.lastError) {
                ensureContentInjected(tabs[0].id, () => {
                  chrome.tabs.sendMessage(tabs[0].id, { action: "set_hsk_levels", levels: hskDisabledLevels });
                });
              }
            }
          );
        });
      });
    });
  });

  // Helper: make sure the content script is injected (needed for tabs that were
  // open before the extension was installed / reloaded).
  function ensureContentInjected(tabId, then) {
    chrome.scripting.executeScript(
      { target: { tabId }, files: INJECT_FILES },
      () => {
        if (chrome.runtime.lastError) {
          showStatus('Could not load on this page.');
          return;
        }
        setTimeout(then, 250);
      }
    );
  }

  // Apply / re-apply HSK settings on the active tab
  function sendHskToTab(tabId, mode, then) {
    chrome.tabs.sendMessage(
      tabId,
      { action: "set_hsk_mode", mode },
      () => {
        if (chrome.runtime.lastError) {
          ensureContentInjected(tabId, () => {
            chrome.tabs.sendMessage(tabId, { action: "set_hsk_mode", mode });
            if (then) then();
          });
        } else if (then) {
          then();
        }
      }
    );
  }

  hskRadios.forEach(radio => {
    radio.addEventListener('change', () => {
      if (!radio.checked) return;
      const mode = radio.value;
      updateHskLegend(mode, hskDisabledLevels);
      chrome.storage.local.set({ hskMode: mode }, () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (!tabs[0]) return;
          sendHskToTab(tabs[0].id, mode, () => {
            chrome.tabs.sendMessage(   // also sync the per-level toggles
              tabs[0].id,
              { action: "set_hsk_levels", levels: hskDisabledLevels },
              () => {}
            );
          });
        });
      });
      const modeName = { off: 'HSK colouring Off', hsk2: 'HSK 2.0 colours', hsk3: 'HSK 3.0 colours' }[mode] || mode;
      showStatus(modeName);
    });
  });

  // On popup open, ping the content script with the current HSK settings. If the
  // tab still runs an old/absent content script (common for tabs open across a
  // extension reload), inject the new scripts and force a re-colour.
  if (hskMode !== 'off') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) return;
      chrome.tabs.sendMessage(
        tabs[0].id,
        { action: "hsk_sync", mode: hskMode, levels: hskDisabledLevels },
        (resp) => {
          if (chrome.runtime.lastError || !(resp && resp.applied)) {
            ensureContentInjected(tabs[0].id, () => {
              chrome.tabs.sendMessage(tabs[0].id, { action: "set_hsk_mode", mode: hskMode }, () => {
                chrome.tabs.sendMessage(tabs[0].id, { action: "set_hsk_levels", levels: hskDisabledLevels }, () => {});
              });
            });
          }
        }
      );
    });
  }
});

function showStatus(message) {
  const statusEl = document.getElementById('status');
  statusEl.textContent = message;
  setTimeout(() => {
    statusEl.textContent = '';
  }, 5000);
}
