// Regex per caratteri cinesi
const CHINESE_RE = /[\u4e00-\u9fff]/;

// Stato dell'estensione
let isEnabled = true;
let isPageProcessed = false;
let selectionEnabled = false;
let targetLang = "en";
let hskMode = "off"; // "off" | "hsk2" | "hsk3"
let hskDisabledLevels = []; // HSK levels (1-9) whose colour coding is turned off

// Inizializza lo stato dallo storage
chrome.storage.local.get(['pinyinEnabled', 'selectionEnabled', 'targetLang', 'hskMode', 'hskDisabledLevels'], (result) => {
  isEnabled = result.pinyinEnabled !== false; // default ON
  selectionEnabled = result.selectionEnabled === true; // default OFF
  targetLang = result.targetLang || "en"; // default English
  hskMode = result.hskMode || "off";
  hskDisabledLevels = Array.isArray(result.hskDisabledLevels) ? result.hskDisabledLevels : [];
  if (selectionEnabled) {
    document.addEventListener('mouseup', onSelectionMouseUp);
  }
});

// ===== Gestione messaggi dal popup =====
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "annotate_page") {
    if (!isEnabled) {
      sendResponse({ status: "disabled", message: "Pinyin disabled" });
      return false;
    }
    if (isPageProcessed) {
      sendResponse({ status: "already_processed" });
      return false;
    }
    processPage()
      .then(() => {
        isPageProcessed = true;
        sendResponse({ status: "success" });
      })
      .catch(err => {
        sendResponse({ status: "error", error: err.message });
      });
    return true;
  }

  if (msg.action === "disable_pinyin") {
    isEnabled = false;
    chrome.storage.local.set({ pinyinEnabled: false });
    if (isPageProcessed) {
      removeAnnotations();
      isPageProcessed = false;
    }
    sendResponse({ status: "disabled" });
    return false;
  }

  if (msg.action === "enable_pinyin") {
    isEnabled = true;
    chrome.storage.local.set({ pinyinEnabled: true });
    if (!isPageProcessed) {
      processPage()
        .then(() => { isPageProcessed = true; })
        .catch(err => console.error("Enable error:", err));
    }
    sendResponse({ status: "enabled" });
    return false;
  }

  if (msg.action === "enable_selection_mode") {
    selectionEnabled = true;
    chrome.storage.local.set({ selectionEnabled: true });
    document.addEventListener('mouseup', onSelectionMouseUp);
    sendResponse({ status: "enabled" });
    return false;
  }

  if (msg.action === "disable_selection_mode") {
    selectionEnabled = false;
    chrome.storage.local.set({ selectionEnabled: false });
    document.removeEventListener('mouseup', onSelectionMouseUp);
    hideTranslationPopup();
    sendResponse({ status: "disabled" });
    return false;
  }

  if (msg.action === "set_target_lang") {
    targetLang = msg.lang || "en";
    chrome.storage.local.set({ targetLang });
    // Si pinyin è attivo, ri-processa la pagina nella nuova lingua
    if (isEnabled && isPageProcessed) {
      removeAnnotations();
      isPageProcessed = false;
      processPage()
        .then(() => { isPageProcessed = true; })
        .catch(err => console.error("Re-translate error:", err));
    }
    sendResponse({ status: "ok", lang: targetLang });
    return false;
  }

  if (msg.action === "set_hsk_mode") {
    hskMode = msg.mode || "off";
    chrome.storage.local.set({ hskMode });
    // Applies colours right away: if the page is already annotated, remove and
    // rebuild; if pinyin is enabled but not yet processed, annotate now so the
    // HSK colours appear immediately.
    if (isEnabled) {
      if (isPageProcessed) {
        removeAnnotations();
        isPageProcessed = false;
      }
      processPage()
        .then(() => { isPageProcessed = true; })
        .catch(err => console.error("HSK mode error:", err));
    }
    sendResponse({ status: "ok", mode: hskMode });
    return false;
  }

  if (msg.action === "set_hsk_levels") {
    hskDisabledLevels = Array.isArray(msg.levels)
      ? msg.levels.filter(n => typeof n === "number" && n >= 1 && n <= 9)
      : [];
    chrome.storage.local.set({ hskDisabledLevels });
    // Re-apply the colours on the already-annotated page
    if (isEnabled && isPageProcessed) {
      removeAnnotations();
      isPageProcessed = false;
      processPage()
        .then(() => { isPageProcessed = true; })
        .catch(err => console.error("HSK levels error:", err));
    }
    sendResponse({ status: "ok", levels: hskDisabledLevels });
    return false;
  }

  if (msg.action === "hsk_sync") {
    // Lightweight check / update used when the popup opens. Does NOT re-annotate.
    hskMode = (typeof msg.mode === "string") ? msg.mode : hskMode;
    if (Array.isArray(msg.levels)) {
      hskDisabledLevels = msg.levels.filter(n => typeof n === "number" && n >= 1 && n <= 9);
    }
    sendResponse({ status: "ok", applied: true, mode: hskMode });
    return false;
  }
});

// ===== Gestione selezione testo (popup automatico) =====
function onSelectionMouseUp(e) {
  if (!selectionEnabled) return;
  if (e.target.closest && e.target.closest("#wry-translation-popup")) return;

  setTimeout(() => {
    const selection = window.getSelection();
    const selectedText = selection.toString().trim();
    if (!selectedText) return;

    let position = { x: e.clientX, y: e.clientY + 12 };
    if (selection.rangeCount > 0) {
      const rect = selection.getRangeAt(0).getBoundingClientRect();
      if (rect.width > 0 || rect.height > 0) {
        position = { x: rect.left + rect.width / 2, y: rect.bottom + 12 };
      }
    }

    showTranslationPopup(selectedText, position).catch(err => {
      console.error("Popup error:", err);
    });
  }, 50);
}

// Rimuove le annotazioni dalla pagina
function removeAnnotations() {
  document.querySelectorAll('.zh-sentence').forEach(el => {
    const parent = el.parentNode;
    if (!parent) return;
    const chineseChars = [];
    el.querySelectorAll('.zh-char').forEach(charEl => {
      chineseChars.push(charEl.textContent);
    });
    parent.insertBefore(document.createTextNode(chineseChars.join('')), el);
    parent.removeChild(el);
  });
  document.body.normalize();
}

function walkTextNodes(root) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false);
  const nodes = [];
  let node;
  while ((node = walker.nextNode())) {
    if (CHINESE_RE.test(node.nodeValue)) nodes.push(node);
  }
  return nodes;
}

async function processPage() {
  const textNodes = walkTextNodes(document.body);
  for (const node of textNodes) {
    // The DOM can change while we await translations (SPA re-render,
    // navigation, or re-annotation). Skip nodes that were detached/removed.
    const parent = node.parentNode;
    if (!parent || !parent.contains(node)) continue;

    const original = node.nodeValue;
    if (!original || !original.trim()) continue;

    const sentences = splitIntoSentences(original);
    const outer = document.createDocumentFragment();

    for (const sentence of sentences) {
      let translation = "";
      try {
        translation = await requestTranslation(sentence);
      } catch (e) {
        translation = "";
      }
      // Re-check before mutating: the node may have been removed while awaiting.
      if (!parent.contains(node)) break;
      outer.appendChild(buildSentenceFragment(sentence, translation));
    }

    if (parent.contains(node)) {
      parent.replaceChild(outer, node);
    }
  }
  return Promise.resolve();
}

// Divide il testo in frasi (mantenendo la punteggiatura allegata alla frase)
function splitIntoSentences(text) {
  const parts = text.split(/(?<=[。！？!?；;…])/);
  const result = [];
  for (const part of parts) {
    const t = part.trim();
    if (t) result.push(t);
  }
  if (result.length === 0 && text.trim()) result.push(text.trim());
  return result;
}

// ===== HSK colour coding =====
// Returns the HSK level (1-9) for a character based on the active mode,
// or 0 if colouring is off / char not found / that level was toggled off.
function getHskLevel(ch) {
  let lv = 0;
  if (hskMode === "hsk2") {
    if (typeof HSK2_CHAR_LEVEL !== "undefined" && HSK2_CHAR_LEVEL[ch]) lv = HSK2_CHAR_LEVEL[ch];
  } else if (hskMode === "hsk3") {
    if (typeof HSK3_CHAR_LEVEL !== "undefined" && HSK3_CHAR_LEVEL[ch]) lv = HSK3_CHAR_LEVEL[ch];
  }
  if (lv > 0 && hskDisabledLevels.indexOf(lv) !== -1) {
    return 0; // user turned off colour coding for this HSK level
  }
  return lv;
}

// Returns the HSK level (1-9) even if that level's colours are disabled
// (used for the title/hover so the learner still knows the level).
function getHskLevelUnfiltered(ch) {
  if (hskMode === "hsk2") {
    if (typeof HSK2_CHAR_LEVEL !== "undefined" && HSK2_CHAR_LEVEL[ch]) return HSK2_CHAR_LEVEL[ch];
  } else if (hskMode === "hsk3") {
    if (typeof HSK3_CHAR_LEVEL !== "undefined" && HSK3_CHAR_LEVEL[ch]) return HSK3_CHAR_LEVEL[ch];
  }
  return 0;
}

// Costruisce una frase annotata: per ogni carattere il pinyin subito sotto,
// e UNA sola traduzione per l'intera frase, su una riga separata sotto.
function buildSentenceFragment(text, translation) {
  const wrapper = document.createElement("span");
  wrapper.className = "zh-sentence";

  const charsLine = document.createElement("span");
  charsLine.className = "zh-chars-line";

  for (const ch of text) {
    if (CHINESE_RE.test(ch)) {
      const block = document.createElement("span");
      block.className = "zh-char-block";
      const hsk = getHskLevel(ch);
      const realHsk = getHskLevelUnfiltered(ch);
      if (realHsk > 0) {
        block.setAttribute("title", hsk > 0 ? "HSK " + hsk : "HSK " + realHsk + " (colour hidden)");
      }
      const charEl = document.createElement("span");
      charEl.className = "zh-char";
      charEl.textContent = ch;
      if (hsk > 0) {
        charEl.classList.add("hsk-lv" + hsk); // colour ONLY the character, not the pinyin
      }
      const pinyinEl = document.createElement("span");
      pinyinEl.className = "zh-pinyin";
      pinyinEl.textContent = getPinyinForChar(ch);
      block.appendChild(charEl);
      block.appendChild(pinyinEl);
      charsLine.appendChild(block);
    } else {
      // Spazio o punteggiatura: lasciali come semplice testo non cinese
      const pad = document.createElement("span");
      pad.className = "zh-pad";
      pad.textContent = ch;
      charsLine.appendChild(pad);
    }
  }

  wrapper.appendChild(charsLine);

  // UNA sola traduzione per l'intera frase, su riga separata sotto
  if (translation) {
    const t = document.createElement("span");
    t.className = "zh-translation";
    t.textContent = translation;
    wrapper.appendChild(t);
  }

  return wrapper;
}

function requestTranslation(text) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(
      { type: "TRANSLATE_TEXT", text, targetLang },
      (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else if (!response || !response.ok) {
          reject(new Error("Translation error"));
        } else {
          resolve(response.translation);
        }
      }
    );
  });
}

// ===== Annotazione pagina compatta =====

function getPinyinForChar(ch) {
  if (typeof LOCAL_PINYIN_DICT !== "undefined" && LOCAL_PINYIN_DICT[ch]) {
    return LOCAL_PINYIN_DICT[ch][0];
  }
  if (typeof pinyin === "function") {
    const r = pinyin(ch);
    if (r && r.length > 0) return r[0];
  }
  return ch;
}

// ===== Popup traduzione selezione =====

function buildPinyinLine(text) {
  const parts = [];
  for (const ch of text) {
    if (CHINESE_RE.test(ch)) {
      const hsk = getHskLevel(ch);
      if (hsk > 0) {
        parts.push('<span class="hsk-lv' + hsk + ' zh-pinyin-span" title="HSK ' + hsk + '">' + getPinyinForChar(ch) + '</span>');
      } else {
        parts.push(getPinyinForChar(ch));
      }
    } else {
      parts.push(ch);
    }
  }
  return parts.join(" ");
}

function hideTranslationPopup() {
  const existing = document.getElementById("wry-translation-popup");
  if (existing) existing.remove();
}

async function showTranslationPopup(text, position) {
  hideTranslationPopup();

  const pinyinLine = buildPinyinLine(text);
  const translation = await requestTranslation(text);

  const popup = document.createElement("div");
  popup.id = "wry-translation-popup";
  popup.innerHTML =
    '<button type="button" class="wry-close" title="Close">&times;</button>' +
    '<div class="wry-label">Chinese</div>' +
    '<div class="wry-chinese"></div>' +
    '<div class="wry-label">Pinyin</div>' +
    '<div class="wry-pinyin"></div>' +
    '<div class="wry-label">Translation</div>' +
    '<div class="wry-translation"></div>';

  function buildChineseHtml(text) {
    let html = "";
    for (const ch of text) {
      if (CHINESE_RE.test(ch)) {
        const hsk = getHskLevel(ch);
        if (hsk > 0) {
          html += '<span class="hsk-lv' + hsk + '" title="HSK ' + hsk + '">' + ch + '</span>';
        } else {
          html += ch;
        }
      } else {
        html += ch.replace(/[&<>"]/g, function (m) {
          return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[m];
        });
      }
    }
    return html;
  }

  popup.querySelector(".wry-chinese").innerHTML = buildChineseHtml(text);
  popup.querySelector(".wry-pinyin").innerHTML = pinyinLine;
  popup.querySelector(".wry-translation").textContent = translation;

  document.body.appendChild(popup);

  const rect = popup.getBoundingClientRect();
  let left = Math.max(8, position.x - rect.width / 2);
  let top = position.y;

  if (left + rect.width > window.innerWidth - 8) {
    left = window.innerWidth - rect.width - 8;
  }
  if (top + rect.height > window.innerHeight - 8) {
    top = Math.max(8, position.y - rect.height - 24);
  }

  popup.style.left = left + "px";
  popup.style.top = top + "px";

  popup.querySelector(".wry-close").addEventListener("click", hideTranslationPopup);

  setTimeout(() => {
    document.addEventListener(
      "click",
      (e) => {
        if (!document.getElementById("wry-translation-popup")) return;
        if (!e.target.closest("#wry-translation-popup")) {
          hideTranslationPopup();
        }
      },
      { once: true }
    );
  }, 0);

  document.addEventListener(
    "keydown",
    (e) => {
      if (e.key === "Escape") hideTranslationPopup();
    },
    { once: true }
  );

  return Promise.resolve();
}