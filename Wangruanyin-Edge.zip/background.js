chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "TRANSLATE_TEXT") {
    const targetLang = message.targetLang || "en";
    translateWithGoogle(message.text, targetLang).then(t => {
      sendResponse({ ok: true, translation: t });
    }).catch(err => {
      sendResponse({ ok: false, error: String(err) });
    });
    return true;
  }
});

async function translateWithGoogle(text, targetLang) {
  const url =
    "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=" +
    encodeURIComponent(targetLang) +
    "&dt=t&q=" +
    encodeURIComponent(text);

  const resp = await fetch(url);
  const data = await resp.json();
  return data[0].map(x => x[0]).join("");
}
